# Fortigen Telegram Bot

Brigadirlar uchun oddiy xarajat kiritish va hisobot boti.

---

## Bot buyruqlari

| Tugma / Buyruq | Nima qiladi |
|---|---|
| 💸 Xarajat qo'shish | Yangi xarajat kiritish (3 qadam) |
| 📊 Bugungi hisobot | Bugun kiritilgan barcha xarajatlar |
| 📋 Holat | Jami xarajat, bugungi, brigada soni |
| /start | Botni boshlash |
| /xarajat | Xarajat kiritish |
| /hisobot | Bugungi hisobot |

---

## O'rnatish tartibi

### 1. Telegram bot yaratish

1. Telegramda **@BotFather** ga `/newbot` yuboring
2. Nom bering: `Fortigen Bot`
3. Username bering: `fortigen_loyiha_bot`
4. **Token** ni nusxalab oling → `.env` ga `BOT_TOKEN=` ga yozing

### 2. Supabase sozlash

1. [supabase.com](https://supabase.com) da loyihangizni oching
2. **SQL Editor** ga kiring
3. `supabase_schema.sql` ichidagi kodni to'liq ko'chirib, **Run** bosing
4. **Settings → API** dan:
   - `Project URL` → `SUPABASE_URL`
   - `service_role` (secret) key → `SUPABASE_KEY`

### 3. O'z Telegram ID ingizni topish

Telegramda **@userinfobot** ga `/start` yuboring → ID raqamingiz chiqadi.
`.env` da `ALLOWED_IDS=` ga shu raqamni yozing.
Brigadirlar ham ishlatsa, ularning ID larini ham vergul bilan qo'shing.

### 4. Railway.app da deploy

1. [railway.app](https://railway.app) ga kiring → **GitHub** bilan login
2. **New Project → Deploy from GitHub** → bu papkani GitHub ga yuklang
3. **Variables** bo'limiga `.env.example` dagi barcha o'zgaruvchilarni kiriting
4. Railway avtomatik `requirements.txt` ni o'qib, botni ishga tushiradi

### 5. Lokal test (ixtiyoriy)

```bash
pip install -r requirements.txt
cp .env.example .env
# .env ni to'ldiring
python bot.py
```

---

## Fayl tuzilmasi

```
fortigen_bot/
├── bot.py               ← asosiy kod
├── requirements.txt     ← kutubxonalar
├── supabase_schema.sql  ← DB jadvallar
├── .env.example         ← muhit o'zgaruvchilari namunasi
└── README.md
```
