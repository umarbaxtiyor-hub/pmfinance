-- ═══════════════════════════════════════════════════
--  FORTIGEN BOT — Supabase jadvallar
--  Supabase → SQL Editor ga ko'chirib ishga tushiring
-- ═══════════════════════════════════════════════════

-- 1. Xarajat turlari (sozlamalar)
create table if not exists xarajat_turlari (
  id   serial primary key,
  nomi text not null unique
);

-- Boshlang'ich turlar
insert into xarajat_turlari (nomi) values
  ('Material'),
  ('Transport'),
  ('Mexanizm ijarasi'),
  ('Mehnat haqi'),
  ('Oziq-ovqat'),
  ('Boshqa')
on conflict do nothing;

-- 2. Brigadalar (mavjud bo'lsa o'tkazib yuboring)
create table if not exists brigadalar (
  id         serial primary key,
  nomi       text not null,
  rang       text default '#38bdf8',
  yaratilgan timestamp default now()
);

-- 3. Xarajatlar — bot shu jadvalga yozadi
create table if not exists xarajatlar (
  id               serial primary key,
  turi             text not null,
  summa            bigint not null,
  izoh             text default '',
  sana             date not null default current_date,
  brigadir         text default '',
  telegram_id      text default '',
  yaratilgan_vaqt  timestamp default now()
);

-- Indeks: sana bo'yicha tezroq so'rov
create index if not exists idx_xarajatlar_sana on xarajatlar(sana);

-- ═══════════════════════════════════════════════════
--  RLS (Row Level Security) — botga to'liq huquq
-- ═══════════════════════════════════════════════════
alter table xarajatlar     enable row level security;
alter table xarajat_turlari enable row level security;
alter table brigadalar     enable row level security;

-- Service key bilan kiruvchi (bot) hamma narsani qila oladi
create policy "bot_full_access_xarajatlar"
  on xarajatlar for all
  using (true) with check (true);

create policy "bot_full_access_xarajat_turlari"
  on xarajat_turlari for all
  using (true) with check (true);

create policy "bot_full_access_brigadalar"
  on brigadalar for all
  using (true) with check (true);
